# Simple Blog API
This is a RESTful API for a simple blog application built using Node.js, Express.js and MongoDB.
It allows users to register, login, and manage blog posts.

## Table of Contents
-[Installation](#installation)
-[API Endpoints](#api-endpoints)
-[Usage](#usage)
-[Technologies Used](#technologies-used)

## Installation
Clone the repository:
    ```bash
    git clone [https://github.com/KaushaniHettiarachchige/test/blob/main/README.md]

Navigate to the project 
    cd BLOG API

Install dependencies
    npm install

Create a e.nv file in root directory
Add mongodb connection URI and JWT secret
    MONGO_URI = ''

Start MongoDB server
    node index.js

## API Endpoints
    HTTP method
    the URL
    request parameters
    request body(POST & PUT)
    JSON

## Usage
    login
    get all posts

## Technologies Used
    node.js
    express.js
    mongoDB
    mongoose
    JWT
    bcrypt
    dotenv